
message = {
    "status_code": None,
    "message": None,
    "items": [
        {
            "event_type": None,
            "result": None
        }
    ]
}
