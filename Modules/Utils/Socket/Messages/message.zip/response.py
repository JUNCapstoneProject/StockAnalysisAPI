
response_message = {
    "response_id": None,
    "status_code": None,
    "message": None,
    "item": {
        "event_type": None,
        "result": None
    }
}
